# 🧪  Experimental

This section is for experiments, cool ideas, and more! 

Code here lives outside the base package. If a project is sufficiently interesting and validated, then we will move it into the core abstractions.
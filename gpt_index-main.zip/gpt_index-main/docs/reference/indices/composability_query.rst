.. _Ref-Composability-Query:

Composable Queries
==================

.. automodule:: gpt_index.indices.query.schema
   :members:
   :inherited-members:
   :exclude-members: 


.. automodule:: gpt_index.data_structs.struct_type
   :members:
   :inherited-members:
   :exclude-members: 

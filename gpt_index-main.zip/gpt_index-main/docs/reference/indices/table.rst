.. _Ref-Indices-Table:

Table Index
===========

Building the Keyword Table Index

.. automodule:: gpt_index.indices.keyword_table
   :members:
   :inherited-members:
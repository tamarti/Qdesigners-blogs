.. _Ref-Indices-VectorStore:

Vector Store Index
==================

Building the Vector Store Index

.. automodule:: gpt_index.indices.vector_store
   :members:
   :inherited-members:
   :exclude-members: delete, docstore, index_struct, index_struct_cls
.. _Ref-Indices-StructStore:

Structured Store Index
======================

.. automodule:: gpt_index.indices.struct_store
   :members:
   :inherited-members:
   :exclude-members: delete, docstore, index_struct, index_struct_cls
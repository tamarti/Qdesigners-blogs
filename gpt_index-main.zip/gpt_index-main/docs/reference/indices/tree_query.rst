Querying a Tree Index
=====================

.. automodule:: gpt_index.indices.query.tree
   :members:
   :inherited-members:
   :exclude-members: index_struct, query, set_llm_predictor, set_prompt_helper
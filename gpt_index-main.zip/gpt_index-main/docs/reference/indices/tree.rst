.. _Ref-Indices-Tree:

Tree Index
==========

Building the Tree Index

.. automodule:: gpt_index.indices.tree
   :members:
   :inherited-members:
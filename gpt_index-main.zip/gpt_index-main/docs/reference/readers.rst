Data Connectors
===============

.. automodule:: gpt_index.readers
   :members:
   :inherited-members:
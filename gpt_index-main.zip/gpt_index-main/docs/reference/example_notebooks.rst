.. _Ref-Example-Notebooks:

Example Notebooks
=================

We offer a wide variety of example notebooks. They are referenced throughout the documentation.

Example notebooks are found `here <https://github.com/jerryjliu/gpt_index/tree/main/examples>`_.
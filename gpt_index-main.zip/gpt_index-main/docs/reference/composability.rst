.. _Ref-Composability:

Composability
=============

Below we show the API reference for composable data structures.

.. automodule:: gpt_index.composability
   :members:
   :inherited-members:
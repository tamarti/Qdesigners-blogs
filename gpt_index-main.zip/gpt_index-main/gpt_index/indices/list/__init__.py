"""List-based data structures."""

from gpt_index.indices.list.base import GPTListIndex

__all__ = [
    "GPTListIndex",
]

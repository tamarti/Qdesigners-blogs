"""Structured store indices."""

from gpt_index.indices.struct_store.sql import GPTSQLStructStoreIndex

__all__ = ["GPTSQLStructStoreIndex"]

"""Prompt class."""

from gpt_index.prompts.base import Prompt

__all__ = ["Prompt"]
